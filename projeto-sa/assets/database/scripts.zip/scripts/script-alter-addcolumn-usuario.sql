ALTER TABLE usuarios ADD COLUMN foto_perfil VARCHAR(255);
